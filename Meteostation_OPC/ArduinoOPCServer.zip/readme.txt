use the forum for help and support

http://www.st4makers.com/forum-and-support